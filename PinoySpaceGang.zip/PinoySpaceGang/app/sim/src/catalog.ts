/**
 * Adapter from the data team's site catalog (web/public/sites.json, schema data/sites.schema.json)
 * to SiteTerrain. The catalog is the single source for site conditions: every value that
 * reaches the physics is copied with its source so the report can cite it.
 *
 * What the catalog gives the physics today:
 *   substrate           → soilType  → plume dust (environment.ts)
 *   conditions.albedo   → albedo    → glare
 *   latitude            → equinox-noon sun elevation → glare / long shadows at the poles
 *   conditions.wind_speed_10m → wind, ONLY when the caller passes opts.windTowardDeg. The
 *                         catalog has a scalar speed (NASA POWER) and no direction, and the
 *                         data team's rule is that a scalar is not a wind vector. For real
 *                         hourly wind vectors use app/lib/environment-site.ts.
 *   conditions.rock_abundance (not in catalog 1.0; read if the data team adds it) → boulders
 */
import type { Body, SiteTerrain } from './types.ts';
import { terrainPackToSite, type TerrainPackManifest } from './loaders.ts';
import { catalogEnvironment, type CatalogEnvironment } from './catalog-environment.ts';

export interface CatalogQuantity {
  [key: string]: unknown;
  value: number | null;
  unit?: string;
  status?: string;
  source?: { product_id?: string; url?: string } | null;
}

export interface CatalogSite {
  /** Preserve additional schema fields instead of projecting them away. */
  [key: string]: unknown;
  id: string;
  name: string;
  body: Body;
  role: 'earth_analog' | 'planetary_target';
  latitude: number;
  longitude: number;
  substrate?: string;
  morphology?: string;
  terrain: { manifest_url: string; rows: number; columns: number; spacing_m: number } | null;
  conditions: Record<string, CatalogQuantity>;
  classification?: Record<string, unknown>;
  identifiers?: string[];
  comparison_features?: Record<string, CatalogQuantity>;
  feature_measurements?: Record<string, CatalogQuantity>;
  resources?: Record<string, unknown>;
  resource_indicators?: unknown[];
  simulation_defaults?: Record<string, unknown>;
  limitations?: string[];
  completeness?: Record<string, unknown>;
}

export interface CatalogPairing {
  [key: string]: unknown;
  earth_id: string;
  planetary_id: string;
  terrain_score: number | null;
  combined_score?: number | null;
}

export interface SiteCatalog {
  schema_version: string;
  sites: CatalogSite[];
  pairings: CatalogPairing[];
}

/** Complete observational record, independent of the simulation's selected inputs. */
export interface SiteCatalogData {
  schema_version: string;
  record: CatalogSite;
  pairings: CatalogPairing[];
  target?: CatalogSite;
  environment: CatalogEnvironment;
}

export interface CatalogSiteOptions {
  /** For Earth analogs: the body to simulate. Never inferred; omit to fly the site as itself. */
  analogOf?: Exclude<Body, 'earth'>;
  /**
   * Compass direction the wind blows towards, degrees (0 = north, 90 = east). A scenario
   * assumption: without it the catalog's scalar wind speed is not applied at all.
   */
  windTowardDeg?: number;
}

/** Pairings that involve a site, best terrain score first. */
export function pairingsFor(catalog: SiteCatalog, siteId: string): CatalogPairing[] {
  return catalog.pairings
    .filter((p) => p.earth_id === siteId || p.planetary_id === siteId)
    .sort((a, b) => (b.terrain_score ?? 0) - (a.terrain_score ?? 0));
}

export function catalogSiteToSite(
  entry: CatalogSite,
  manifest: TerrainPackManifest,
  buffer: ArrayBufferLike,
  opts: CatalogSiteOptions = {},
  catalog?: SiteCatalog,
): SiteTerrain {
  const site = terrainPackToSite(manifest, buffer, { analogOf: opts.analogOf });
  const sources: Record<string, string> = {};
  const q = (key: string) => {
    const c = entry.conditions[key];
    if (!c || typeof c.value !== 'number') return undefined;
    sources[key] = [c.source?.product_id, c.status].filter(Boolean).join(', ') || 'site catalog';
    return c.value;
  };

  const out: SiteTerrain = { ...site, id: entry.id, name: entry.name, body: entry.body,
    catalog: { schema_version: catalog?.schema_version ?? '1.0.0', record: entry,
      environment: catalogEnvironment(entry.id),
      pairings: catalog?.pairings.filter(p => p.earth_id === entry.id || p.planetary_id === entry.id) ?? [] } };
  if (entry.substrate && entry.substrate !== 'unknown') {
    out.soilType = entry.substrate.replace(/_/g, ' ');
    sources.soilType = 'site catalog substrate label (interpreted)';
  }
  out.albedo = q('albedo');
  if (opts.windTowardDeg !== undefined) {
    const speed = q('wind_speed_10m');
    if (speed !== undefined) {
      const toward = (opts.windTowardDeg * Math.PI) / 180;
      out.wind = { x: speed * Math.sin(toward), y: speed * Math.cos(toward) };
      sources.wind_speed_10m += `; direction is a scenario assumption (${opts.windTowardDeg}° toward)`;
    }
  }
  out.rockAbundance = q('rock_abundance');
  out.sunElevationDeg = Math.max(0, 90 - Math.abs(entry.latitude));
  sources.sunElevationDeg = 'equinox noon sun elevation from catalog latitude';
  out.sources = sources;
  return out;
}
