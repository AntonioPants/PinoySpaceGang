/**
 * Adapters from the data team's terrain formats to SiteTerrain.
 *
 *  - profileToSite():     JSON documents from scripts/extract_profile.py
 *                         (validated by data/terrain_profile.schema.json)
 *  - terrainPackToSite(): browser terrain packs in web/public/terrain/<id>/
 *                         (manifest.json + little-endian float32 elevation grid)
 *
 * Both formats store rows north → south; SiteTerrain rows run south → north (y = north), so rows
 * are flipped. The grid is centred on (0, 0), so the default landing target is the middle of the map.
 */
import type { Body, SiteTerrain } from './types.ts';

type AnalogOf = Exclude<Body, 'earth'>;

export interface TerrainProfile {
  site: { id: string; name: string; type: 'earth_analog' | 'planetary_site'; body: Body };
  spatial: { width: number; height: number; resolution_m: { x: number; y: number } };
  terrain: { elevation_m: Array<Array<number | null>>; roughness_rms_m?: Array<Array<number | null>> };
}

export function profileToSite(profile: TerrainProfile, opts: { analogOf?: AnalogOf } = {}): SiteTerrain {
  const grid = profile?.terrain?.elevation_m;
  if (!Array.isArray(grid) || grid.length < 2) throw new Error('profile.terrain.elevation_m must be a 2D grid');
  const rows = grid.length;
  if (!Array.isArray(grid[0]) || grid[0].length < 2) throw new Error('profile elevation grid must have at least two columns');
  const cols = grid[0].length;
  if (grid.some((r) => !Array.isArray(r) || r.length !== cols)) throw new Error('profile.terrain.elevation_m rows have different lengths');
  const { x, y } = profile.spatial.resolution_m;
  if (!(Number.isFinite(x) && Number.isFinite(y) && x > 0 && y > 0)) throw new Error('profile.spatial.resolution_m must be positive');
  if (x !== y) throw new Error('profile requires equal X/Y spacing; resample to square cells before simulation');
  if (profile.spatial.width !== cols || profile.spatial.height !== rows) throw new Error('profile dimensions do not match elevation grid');
  if (!['earth', 'moon', 'mars'].includes(profile.site.body)) throw new Error('unknown profile body');

  if (grid.some(row => row.some(value => typeof value !== 'number' || !Number.isFinite(value)))) {
    throw new Error('profile contains missing or nonfinite elevations; no synthetic filling is permitted');
  }

  const heights = new Float32Array(rows * cols);
  for (let r = 0; r < rows; r++) {
    const src = grid[rows - 1 - r];
    for (let c = 0; c < cols; c++) {
      const v = src[c];
      heights[r * cols + c] = v as number;
      if (!Number.isFinite(heights[r * cols + c])) throw new Error('profile elevation exceeds float32 range');
    }
  }
  const body = profile.site.body;
  const cellSize = x;
  // roughness_rms_m, same grid: modulates where generated boulders cluster (see surface.ts)
  let roughnessGrid: SiteTerrain['roughnessGrid'];
  const rough = profile.terrain.roughness_rms_m;
  if (rough !== undefined) {
    if (!Array.isArray(rough) || rough.length !== rows || rough.some(row => !Array.isArray(row) || row.length !== cols || row.some(v => typeof v !== 'number' || !Number.isFinite(v) || v < 0))) {
      throw new Error('profile roughness grid contains missing, invalid or misaligned samples');
    }
    const rh = new Float32Array(rows * cols);
    for (let r = 0; r < rows; r++) for (let c = 0; c < cols; c++) {
      rh[r * cols + c] = rough[rows - 1 - r][c] as number;
      if (!Number.isFinite(rh[r * cols + c])) throw new Error('profile roughness exceeds float32 range');
    }
    roughnessGrid = { cols, rows, cellSize, heights: rh };
  }
  return {
    id: profile.site.id,
    name: profile.site.name,
    body,
    analogOf: body === 'earth' ? opts.analogOf : undefined,
    heightmap: { cols, rows, cellSize, heights },
    roughnessGrid,
  };
}

export interface TerrainPackManifest {
  schema_version: number;
  id: string;
  name: string;
  body: string;
  grid: { rows: number; columns: number; spacing_m: number; dtype: string; byte_order: string; order?: string };
}

export function terrainPackToSite(
  manifest: TerrainPackManifest,
  buffer: ArrayBufferLike,
  opts: { analogOf?: AnalogOf } = {},
): SiteTerrain {
  const { rows, columns: cols, spacing_m, dtype, byte_order } = manifest.grid;
  if (manifest.schema_version !== 1) throw new Error('unsupported terrain schema version');
  if (!Number.isInteger(rows) || rows < 2 || !Number.isInteger(cols) || cols < 2 ||
      !Number.isFinite(spacing_m) || spacing_m <= 0) throw new Error('invalid terrain dimensions or spacing');
  if (!['north-first, west-first', 'row-major; north to south, west to east'].includes(manifest.grid.order ?? ''))
    throw new Error('unsupported or missing terrain row/column order');
  if (dtype !== 'float32' || byte_order !== 'little-endian') throw new Error(`unsupported grid ${dtype}/${byte_order}`);
  if (buffer.byteLength !== rows * cols * 4)
    throw new Error(`elevation file has ${buffer.byteLength} bytes, expected ${rows * cols * 4}`);
  const view = new DataView(buffer);
  const heights = new Float32Array(rows * cols);
  for (let r = 0; r < rows; r++) {
    const srcRow = rows - 1 - r;
    for (let c = 0; c < cols; c++) {
      const v = view.getFloat32((srcRow * cols + c) * 4, true);
      if (!Number.isFinite(v)) throw new Error(`invalid elevation at row ${srcRow}, col ${c}`);
      heights[r * cols + c] = v;
    }
  }
  const body = manifest.body.toLowerCase() as Body;
  if (!['earth', 'moon', 'mars'].includes(body)) throw new Error(`unknown body ${manifest.body}`);
  return {
    id: manifest.id,
    name: manifest.name,
    body,
    analogOf: body === 'earth' ? opts.analogOf : undefined,
    heightmap: { cols, rows, cellSize: spacing_m, heights },
  };
}
